import time
from termcolor import colored
import string
import os

integer_i_have_to_create_because_of_lag_kinda_l = 1234567543234567654345676543456776543456787654567765

state = {
    1
}

default_name = ("moon")

has_run = False
user_name_change = False

def startup():
    global has_run
    if not has_run:
        time.sleep(1)
        print(colored("moon: ...","white",attrs=['bold']))
        time.sleep(0.345)
        print(colored("moon: loading canisters","white",attrs=['bold']))
        time.sleep(0.45)
        print(colored("moon: ready!","green",attrs=['bold']))
        time.sleep(0.25)
        if not user_name_change:
            global user_name
            user_name = input(colored(f"{default_name}@moon","green",attrs=['bold'])+(":") + colored("~","blue",attrs=['bold']) + ("$ "))
            if user_name == 'placeholder':
                user_name = default_name
        else:
            main()
        has_run = True
    else:
        main()
    main()


def main():
    if any(char in string.punctuation for char in user_name):
        print(colored(f"moon: {user_name}, is a invalid username. restarting terminal.","white",attrs=['bold']))
        restart(3.27)
    else:
        prompt = input(colored(f"{user_name}@moon","green",attrs=['bold'])+(":") + colored("~","blue",attrs=['bold']) + ("$ "))
        cmd = prompt.split()
        if 'land' in cmd:
            print(colored(' '.join(cmd[1:]), "white",attrs=['bold']))
            main()
        elif 'create' in cmd:
            global text
            text = ' '.join(cmd[2:])
            filename = cmd[1]
            file_extension = filename.split(".")[-1]
            if file_extension == 'txt':
                filename = filename + ".txt"
                txt(filename)
            else:
                print(f"{filename}, does not exist or is a invalid extension.")
            main()
        elif 'open' in cmd:
            c = cmd[1]
            open_file(c)
            main()
        elif 'restart' in cmd:
            restart(3.27)
        elif 'reboot' in cmd:
            global has_run
            has_run = False
            restart(4.38)
        elif 'end' in cmd:
            end()
        elif 'delete' in cmd:
            try:
                x = cmd[1]
                delete_file(x)
            except FileNotFoundError:
                    print("file does not exist.")
            else:
                print(colored(f"succesfully deleted,{x}.","green",attrs=['bold']))
            main()
        elif 'wait' in cmd:
            length = float(cmd[1])
            wait(length)
        elif 'username' in cmd:
            global l
            l = cmd[1]
            change_user_name(l)
        elif prompt == '':
            main()
        else:
            print(colored(f"{prompt}, is a invalid command", " red",attrs=['bold']))


def wait(length):
    time.sleep(length)
    main()

def open_file(filename):
    with open(filename, 'r') as f:
        contents = f.read()
    print(filename,": ",contents)

def restart(length):
    time.sleep(length)
    startup()

def end():
    prompt = input(colored(f"{user_name}@moon","green",attrs=['bold'])+(":") + colored("~","blue",attrs=['bold']) + ("$ would you like to end the current session:[y/n] "))
    if prompt == 'y':
        print(state)
        global i
        i = False
    elif prompt == 'n':
        main()

def delete_file(filename):
    os.remove(filename)
    main()

def txt(filename):
    with open(filename, 'a') as f:
        f.write(text)

def change_user_name(name):
    global user_name
    user_name = name
    global user_name_change
    user_name_change = True
    main()

def check_state():
    global i
    for i in range(integer_i_have_to_create_because_of_lag_kinda_l):
        if i is True:
            g = 1 + i
            state.append(g)


startup()